#ifndef _PCEM_DEVICES_H_
#define _PCEM_DEVICES_H_

#include <pcem/api.h>

#include <pcem/cpu.h>

#define CONFIG_STRING 0
#define CONFIG_INT 1
#define CONFIG_BINARY 2
#define CONFIG_SELECTION 3
#define CONFIG_MIDI 4

enum {
        DEVICE_NOT_WORKING = 1, /*Device does not currently work correctly and will be disabled in a release build*/
        DEVICE_AT = 2,          /*Device requires an AT-compatible system*/
        DEVICE_MCA = 0x20,      /*Device requires an MCA system*/
        DEVICE_PCI = 0x40,      /*Device requires a PCI system*/
        DEVICE_PS1 = 0x80       /*Device is only for IBM PS/1 Model 2011*/
};

typedef struct device_config_selection_t {
        char description[256];
        int value;
} device_config_selection_t;

typedef struct device_config_t {
        char name[256];
        char description[256];
        int type;
        char default_string[256];
        int default_int;
        device_config_selection_t selection[30];
} device_config_t;

typedef struct device_t {
        char name[50];
        uint32_t flags;
        void *(*init)();
        void (*close)(void *p);
        int (*available)();
        void (*speed_changed)(void *p);
        void (*force_redraw)(void *p);
        void (*add_status_info)(char *s, int max_len, void *p);
        device_config_t *config;
} device_t;

typedef struct SOUND_CARD {
        char name[64];
        char internal_name[24];
        device_t *device;
} SOUND_CARD;

typedef struct video_timings_t {
        int type;
        int write_b, write_w, write_l;
        int read_b, read_w, read_l;
} video_timings_t;

typedef struct VIDEO_CARD {
        char name[64];
        char internal_name[24];
        device_t *device;
        int legacy_id;
        int flags;
        video_timings_t timing;
} VIDEO_CARD;

typedef struct MODEL {
        char name[64];
        int id;
        char internal_name[24];
        struct {
                char name[8];
                CPU *cpus;
        } cpu[5];
        int flags;
        int min_ram, max_ram;
        int ram_granularity;
        void (*init)();
        struct device_t *device;
} MODEL;

typedef struct HDD_CONTROLLER {
        char name[50];
        char internal_name[16];
        device_t *device;
        int is_mfm;
        int is_ide;
        int is_scsi;
} HDD_CONTROLLER;

typedef struct NETWORK_CARD {
        char name[32];
        char internal_name[24];
        device_t *device;
} NETWORK_CARD;

typedef struct lpt_device_t {
        char name[50];
        uint32_t flags;
        void *(*init)();
        void (*close)(void *p);
        int (*available)();
        void (*speed_changed)(void *p);
        void (*force_redraw)(void *p);
        void (*add_status_info)(char *s, int max_len, void *p);
        device_config_t *config;
        void (*write_data)(uint8_t val, void *p);
        void (*write_ctrl)(uint8_t val, void *p);
        uint8_t (*read_status)(void *p);
} lpt_device_t;

typedef struct LPT_DEVICE {
        char name[64];
        char internal_name[16];
        lpt_device_t *device;
} LPT_DEVICE;

#define MOUSE_TYPE_SERIAL 0
#define MOUSE_TYPE_PS2 1
#define MOUSE_TYPE_AMSTRAD 2
#define MOUSE_TYPE_OLIM24 3

#define MOUSE_TYPE_IF_MASK 3

#define MOUSE_TYPE_3BUTTON (1 << 31)

typedef struct mouse_t {
        char name[80];
        void *(*init)();
        void (*close)(void *p);
        void (*poll)(int x, int y, int z, int b, void *p);
        int type;
} mouse_t;

#define AXIS_NOT_PRESENT -99999

typedef struct joystick_if_t {
        char name[80];
        void *(*init)();
        void (*close)(void *p);
        uint8_t (*read)(void *p);
        void (*write)(void *p);
        int (*read_axis)(void *p, int axis);
        void (*a0_over)(void *p);
        int axis_count, button_count, pov_count;
        int max_joysticks;
        char axis_names[8][32];
        char button_names[32][32];
        char pov_names[4][32];
} joystick_if_t;

PCEM_API extern void pcem_add_model(MODEL *model);
PCEM_API extern void pcem_add_video(VIDEO_CARD *video);
PCEM_API extern void pcem_add_sound(SOUND_CARD *sound);
PCEM_API extern void pcem_add_lpt(LPT_DEVICE *lpt);
PCEM_API extern void pcem_add_hddcontroller(HDD_CONTROLLER *hddcontroller);
PCEM_API extern void pcem_add_networkcard(NETWORK_CARD *netcard);
PCEM_API extern void pcem_add_mouse(mouse_t *mouse);
PCEM_API extern void pcem_add_joystick(joystick_if_t *joystick);
PCEM_API extern void pcem_add_device(device_t *device);

PCEM_API extern int pcem_device_get_config_int(device_t *device, char *name);
PCEM_API extern char *pcem_device_get_config_string(device_t *device, char *s);
PCEM_API extern int pcem_model_get_config_int(device_t *device, char *s);
PCEM_API extern char *pcem_model_get_config_string(device_t *device, char *s);
PCEM_API extern device_t *pcem_model_getdevice(int model);

#endif /* _PCEM_DEVICES_H_ */
